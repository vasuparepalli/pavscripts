package com.pav.paralleltest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.pav.parallel.testdata.FinancialTransaction;
import com.pav.parallel.testdata.HPXInputXML;
import com.pav.paralleltest.FileUtils;
import com.pav.paralleltest.InitializationUtil;
import com.pav.paralleltest.PropertyUtils;

public class App {
	String baseProjectPath = System.getProperty("user.dir");
	ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	ExtentTest logger;
	// ExtentHtmlReporter htmlReporter;
	String logfilepath;
	String baseProjPath = System.getProperty("user.dir");
	String orgsList= System.getProperty("orgName"); //"BCBSNC,PREMERA";
	String environment=System.getProperty("environment");// "batche2e";
	String buildnumber=System.getProperty("buildno");//"2022";
	PropertyUtils props = new PropertyUtils(baseProjectPath.concat("/src/main/resources/config.property"));
	String orgs[]=null;
	Logger LOG = LoggerFactory.getLogger(App.class);
	FileUtils fUtils = new FileUtils();
	InitializationUtil inUtil = new InitializationUtil();

	@BeforeTest
	public void setUpReport() {
		htmlReporter = new ExtentHtmlReporter(props.getProperty("destPath").concat("/test-output/paymentfiles.html"));
		extent = new ExtentReports();
		extent.setSystemInfo("Host Name", "Test");
		extent.setSystemInfo("Environment", environment);
		extent.setSystemInfo("User Name", "Test");
		htmlReporter.loadXMLConfig(new File(System.getProperty("user.dir") + "/extent-config.xml"));
		extent.attachReporter(htmlReporter);
		if(orgsList.contains(",")) {
			orgs=orgsList.split(",");
		}
		else {
			orgs=new String[] {orgsList};
		}
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy-HH-mm-ss");
		Date date = new Date();
		System.out.println(formatter.format(date));
		String logfilename = "log" + (formatter.format(date)) + ".log";
		logfilepath = props.getProperty("destPath").concat("/test-output/").concat(logfilename);

		File file = new File(logfilepath);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			Properties properties = new Properties();
			InputStream configStream = new FileInputStream(baseProjPath.concat("/src/main/resources/log4j.properties"));
			properties.load(configStream);
			configStream.close();
			properties.setProperty("log4j.appender.R.File", logfilepath);
			LogManager.resetConfiguration();
			PropertyConfigurator.configure(properties);
		} catch (Exception exception) {
			System.out.println("Error in finding the log file::" + exception.getMessage());
		}
		// logger=extent.createTest("dsdsds");
		// logger = extent.createTest("sadasdasda");
	}

	@Test
	public void xmlTest() throws Exception { 
		System.out.println("Property is: " + props.getProperty("FinanceCheckRecordArrayElements"));
		for (String orgName : orgs) {
			String[] planCodes = inUtil.getPlanCodesForOrg(orgName, props);
			for (String planCode : planCodes) {
				String[] payTypes = inUtil.getPayTypes(orgName,planCode,props);
				for (String payType : payTypes) {
					String expDirName = props.getProperty("expPath").concat("/").concat(orgName).concat("/").concat(planCode).concat("/").concat(payType);
					String actDirName = props.getProperty("destPath").concat("/").concat(buildnumber).concat("/").concat(orgName).concat("/").concat(planCode).concat("/").concat(payType);
					System.out.println("Expected File Path is in location: "+expDirName);
					System.out.println("Actual File Path is in location: "+actDirName);
					ArrayList<String> expFileNames = fUtils.getFilesFromDir(expDirName);
					ArrayList<String> actFileNames = fUtils.getFilesFromDir(actDirName);
					if (expFileNames.size() != 1 || actFileNames.size() != 1) {
						logger = extent.createTest(expDirName);
						System.out.println("ERROR !! - Either expected or Actual have either more than 1 or 0 files.");
						logger.log(Status.FAIL, "Either expected or Actual have either more than 1 or 0 files.");
						LOG.info("Either expected or Actual have either more than 1 or 0 files.");
						LOG.info("DDDDDD " + logger.getStatus());

					} else {
						try {
							String expectedOnlyfilename = expFileNames.get(0);
							String actualOnlyfilename = actFileNames.get(0);
							String expectedfilename = expDirName + "/" + expectedOnlyfilename;
							String actualfilename = actDirName + "/" + actualOnlyfilename;
							LOG.info("Expected File -- " + expectedfilename);
							LOG.info("Actual File -- " + actualfilename);
							// Convert all values that has to be validated to key value pair for iteration
							StringBuilder sbExpected = fUtils.readFileToString(expectedfilename);
							StringBuilder sbActual = fUtils.readFileToString(actualfilename);
							switch (orgName) {
							case "CAREFIRST":
								logger = extent.createTest(orgName + " - " + expectedOnlyfilename);
								validateCarefirst(expectedOnlyfilename, sbExpected, sbActual, payType);
								break;
							case "BCBSNC":
								logger = extent.createTest(orgName + " - " + expectedOnlyfilename);
								validateNonCarefirst(expectedOnlyfilename, sbExpected, sbActual, payType);
								break;
							case "PREMERA":
								logger = extent.createTest(orgName + " - " + expectedOnlyfilename);
								validateNonCarefirst(expectedOnlyfilename, sbExpected, sbActual, payType);
								break;
							case "WELLMARK":
								logger = extent.createTest(orgName + " - " + expectedOnlyfilename);
								validateNonCarefirst(expectedOnlyfilename, sbExpected, sbActual, payType);
								break;
							}
						} catch (Exception e) {
							logger.log(Status.ERROR, "Error parsing xml");
						}
					}

					if (logger.getStatus().toString().equalsIgnoreCase("skip")
							|| logger.getStatus().toString().equalsIgnoreCase("fail")
							|| logger.getStatus().toString().equalsIgnoreCase("error")) {

					} else {
						logger.log(Status.PASS, "All elements passed");
					}
				}

			}
		}
	}

	private void validateNonCarefirst(String expectedOnlyfilename, StringBuilder sbExpected, StringBuilder sbActual,
			String payType) {
		try {

			FinancialTransaction objExpected = fUtils.unmarshallFTXML(sbExpected);
			FinancialTransaction objActual = fUtils.unmarshallFTXML(sbActual);
			HashMap<String, String[]> keyValueForFields = new HashMap<String, String[]>();
			keyValueForFields = inUtil.getKeyValueForFields(payType);
			if (objActual.getDetail().size() != objExpected.getDetail().size()) {
				logger.log(Status.FAIL, "Count of Detail do not match. Expected -" + objExpected.getDetail().size()
						+ " Actual - " + objActual.getDetail().size());
				LOG.info("Count of mailset do not match. Expected -" + objExpected.getDetail().size() + " Actual - "
						+ objActual.getDetail().size());

			}
			AssertionUtilOthers.iterCheck = 0;
			for (int expCtr = 0; expCtr < objExpected.getDetail().size(); expCtr++) {
				String expPayIdNo = objExpected.getDetail().get(expCtr).getFinanceCheckRecordArray().getPayeeIDNumber();
				if (expPayIdNo == "" || expPayIdNo.isEmpty()) {
					logger.log(Status.SKIP, "Empty Payee No detected");

					LOG.info("Empty Payee No detected");
				} else {

					System.out.println("Payee ID Number Expected:" + expPayIdNo);

					boolean idFound = false;

					for (int actCtr = 0; actCtr < objActual.getDetail().size(); actCtr++) {
						String actPayIdNo = objActual.getDetail().get(actCtr).getFinanceCheckRecordArray()
								.getPayeeIDNumber();
						if (actPayIdNo.equalsIgnoreCase(expPayIdNo)) {
							idFound = true;
							System.out.println("Match Found. Index is " + actCtr + " for PayeeID " + actPayIdNo);
							Iterator iterator = keyValueForFields.entrySet().iterator();

							while (iterator.hasNext()) {

								Map.Entry mapElement = (Map.Entry) iterator.next();
								String fieldType = (String) mapElement.getKey();
								String[] fieldsToValidate = (String[]) mapElement.getValue();
								System.out.println("Starting Validation for " + fieldType);
								LOG.info("Starting Validation for " + fieldType);

								for (String field : fieldsToValidate) {
									AssertionUtilOthers utilObj = new AssertionUtilOthers(logger, LOG,
											expectedOnlyfilename);
									utilObj.assertValues(objExpected, objActual, expCtr, actCtr, field);
								}

							}
							extent.flush();
						}

					}
					if (!idFound) {
						System.out.println("Match Not Found for Payee ID Number " + expPayIdNo);
						logger.log(Status.FAIL, "Match Not Found for Payee ID Number " + expPayIdNo);
						LOG.info("Match Not Found for Payee ID Number " + expPayIdNo);
					}

				}

			}

			LOG.info("Overall Run Status " + logger.getStatus());

		} catch (JAXBException e) {
			logger.log(Status.ERROR, "Error Parsing file");
			e.printStackTrace();
		}

	}

	private void validateCarefirst(String expectedOnlyfilename, StringBuilder sbExpected, StringBuilder sbActual,
			String payType) {
		try {

			HPXInputXML objExpected = fUtils.unmarshallXML(sbExpected);
			HPXInputXML objActual = fUtils.unmarshallXML(sbActual);
			HashMap<String, String[]> keyValueForFields = new HashMap<String, String[]>();
			keyValueForFields = inUtil.getKeyValueForFields(payType);

			if (objActual.getMailset().size() != objExpected.getMailset().size()) {
				logger.log(Status.FAIL, "Count of mailset do not match. Expected -" + objExpected.getMailset().size()
						+ " Actual - " + objActual.getMailset().size());
				LOG.info("Count of mailset do not match. Expected -" + objExpected.getMailset().size() + " Actual - "
						+ objActual.getMailset().size());

			}
			for (int expCtr = 0; expCtr < objExpected.getMailset().size(); expCtr++) {
				String expPayIdNo = objExpected.getMailset().get(expCtr).getFinanceCheckRecordArray()
						.getPayeeIDNumber();
				if (expPayIdNo == "" || expPayIdNo.isEmpty()) {
					logger.log(Status.SKIP, "Empty Payee No detected");
					LOG.info("Empty Payee No detected");
				} else {

					System.out.println("Payee ID Number Expected:" + expPayIdNo);

					boolean idFound = false;
					AssertionUtilCarefirst.iterCheck = 0;
					for (int actCtr = 0; actCtr < objActual.getMailset().size(); actCtr++) {
						String actPayIdNo = objActual.getMailset().get(actCtr).getFinanceCheckRecordArray()
								.getPayeeIDNumber();
						if (actPayIdNo.equalsIgnoreCase(expPayIdNo)) {
							idFound = true;
							System.out.println("Match Found. Index is " + actCtr + " for PayeeID " + actPayIdNo);
							Iterator iterator = keyValueForFields.entrySet().iterator();

							while (iterator.hasNext()) {

								Map.Entry mapElement = (Map.Entry) iterator.next();
								String fieldType = (String) mapElement.getKey();
								String[] fieldsToValidate = (String[]) mapElement.getValue();
								System.out.println("Starting Validation for " + fieldType);
								LOG.info("Starting Validation for " + fieldType);

								for (String field : fieldsToValidate) {
									AssertionUtilCarefirst utilObj = new AssertionUtilCarefirst(logger, LOG,
											expectedOnlyfilename);
									utilObj.assertValues(objExpected, objActual, expCtr, actCtr, field);
									// utilObj.assertValues(objExpected, objActual, expCtr, actCtr,
									// field).putAll(results);;
								}

							}
							extent.flush();
						}

					}
					if (!idFound) {
						System.out.println("Match Not Found for Payee ID Number " + expPayIdNo);
						logger.log(Status.FAIL, "Match Not Found for Payee ID Number " + expPayIdNo);
						LOG.info("Match Not Found for Payee ID Number " + expPayIdNo);
					}

				}

			}

		} catch (JAXBException e) {
			e.printStackTrace();
		}

	}

	@AfterTest
	public void endReport() {
		// extent.endTest(logger);
		extent.flush();
		// extent.close();
	}

}