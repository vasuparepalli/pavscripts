package com.pav.paralleltest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class FlatFileComparison {
	String baseProjectPath = System.getProperty("user.dir");
	ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	ExtentTest logger;
	String logfilepath;
	String baseProjPath = System.getProperty("user.dir");
	String orgsList = System.getProperty("orgName");
	// "BCBSNC,PREMERA";
	String environment = System.getProperty("environment");//
	// "batche2e";
	String buildnumber = System.getProperty("buildno");// "2022";
	PropertyUtils props = new PropertyUtils(baseProjectPath.concat("/src/main/resources/glconfig.property"));
	String orgs[] = null;
	Logger LOG = LoggerFactory.getLogger(App.class);
	InitializationUtil inUtil = new InitializationUtil();
	FileUtils fUtils = new FileUtils();
	LinkedHashMap<Integer, String> expectedFileMapping = new LinkedHashMap<Integer, String>();
	LinkedHashMap<Integer, String> actualFileMapping = new LinkedHashMap<Integer, String>();
	List<LinkedHashMap<String, String>> mappedRecords = null;
	ArrayList<String> keysList = new ArrayList<String>();

	@BeforeTest
	public void setUpReport() {
		htmlReporter = new ExtentHtmlReporter(props.getProperty("destPath").concat("/test-output/glreport.html"));
		extent = new ExtentReports();
		extent.setSystemInfo("Host Name", "Test");
		extent.setSystemInfo("Environment", "Test");
		extent.setSystemInfo("User Name", "Test");
		htmlReporter.loadXMLConfig(new File(System.getProperty("user.dir") + "/extent-config.xml"));
		extent.attachReporter(htmlReporter);
		if (orgsList.contains(",")) {
			orgs = orgsList.split(",");
		} else {
			orgs = new String[] { orgsList };
		}
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy-HH-mm-ss");
		Date date = new Date();
		System.out.println(formatter.format(date));
		String logfilename = "log" + (formatter.format(date)) + ".log";
		logfilepath = props.getProperty("destPath").concat("/test-output/").concat(logfilename);
		File file = new File(logfilepath);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			Properties properties = new Properties();
			InputStream configStream = new FileInputStream(baseProjPath.concat("/src/main/resources/log4j.properties"));
			properties.load(configStream);
			configStream.close();
			properties.setProperty("log4j.appender.R.File", logfilepath);
			LogManager.resetConfiguration();
			PropertyConfigurator.configure(properties);
		} catch (Exception exception) {
			System.out.println("Error in finding the log file::" + exception.getMessage());
		}
	}

	@Test
	public void readFile() throws Exception {
		for (String orgName : orgs) {
			String[] planCodes = inUtil.getPlanCodesForOrg(orgName, props);
			for (String planCode : planCodes) {
				String[] payTypes = inUtil.getPayTypes(orgName, planCode, props);
				for (String payType : payTypes) {
					PropertyUtils utils = null;
					if (payType.equals("GL")) {
						utils = new PropertyUtils(baseProjectPath.concat("/src/main/resources/ElemPosition.property"));
					} else if (payType.equals("CASH")) {
						utils = new PropertyUtils(baseProjectPath.concat("/src/main/resources/cash.property"));
					}

					String actDirName = props.getProperty("destPath").concat("/").concat(buildnumber).concat("/")
							.concat(orgName).concat("/").concat(planCode).concat("/").concat(payType);
					String expDirName = props.getProperty("expPath").concat("/").concat(orgName).concat("/")
							.concat(planCode).concat("/").concat(payType);
					ArrayList<String> expFileNames = fUtils.getTxtFilesFromDir(expDirName);
					ArrayList<String> actFileNames = fUtils.getTxtFilesFromDir(actDirName);
					if (expFileNames.size() != 1 || actFileNames.size() != 1) {
						logger = extent.createTest(expDirName);
						System.out.println("ERROR !! - Either expected or Actual have either more than 1 or 0 files.");
						logger.log(Status.FAIL, "Either expected or Actual have either more than 1 or 0 files.");
						LOG.info("Either expected or Actual have either more than 1 or 0 files.");
						LOG.info("Status " + logger.getStatus());

					} else {
						try {
							logger = extent.createTest(planCode + "-" + payType);
							LOG.info("****Execution for the plan code : " + payType);
							String expectedOnlyfilename = expFileNames.get(0);
							String actualOnlyfilename = actFileNames.get(0);
							String expectedfilename = expDirName + "/" + expectedOnlyfilename;
							String actualfilename = actDirName + "/" + actualOnlyfilename;
							LOG.info("Expected File -- " + expectedfilename);
							LOG.info("Actual File -- " + actualfilename);
							expectedFileMapping = fileToStrobj(expectedfilename);
							System.out.println("Expected File Records: " + expectedFileMapping);
							actualFileMapping = fileToStrobj(actualfilename);
							System.out.println("Actual File Records: " + actualFileMapping);
							if (expectedFileMapping.size() == actualFileMapping.size()) {
								List<LinkedHashMap<String, String>> expectedMappedRecords = buildImpl(
										expectedFileMapping, utils);
								List<LinkedHashMap<String, String>> actualMappedRecords = buildImpl(actualFileMapping,
										utils);
								compareRecords(expectedMappedRecords, actualMappedRecords);
							} else {
								System.out.println("Count of records doesn't macth..");
								logger.log(Status.FAIL,
										"Count of Records doesn't match - Expected File Record size: "
												+ expectedFileMapping.size() + " Actual File Record size: "
												+ actualFileMapping.size()
												+ " - Find more information from log file at the path: ");
							}
							extent.flush();
						} catch (Exception ex) {
							ex.printStackTrace();
							logger.log(Status.ERROR, "Error in file comparision");
						}
					}

				}
			}
		}
	}

	public void compareRecords(List<LinkedHashMap<String, String>> exp, List<LinkedHashMap<String, String>> act) {
		System.out.println("Expec:" + exp);
		System.out.println("Actual: " + act);
		for (int i = 0; i < exp.size(); i++) {
			for (int j = 0; j < exp.get(i).size(); j++) {
				if (exp.get(i).get(keysList.get(j)).equals(act.get(i).get(keysList.get(j)))) {
					System.out.println("Records Matched..");
					System.out.println("Expected Record value: Record Position: " + i + " Key is: " + keysList.get(j)
							+ " Value is: " + exp.get(i).get(keysList.get(j)));
					System.out.println("Actual Record value: Record Position: " + i + " Key is: " + keysList.get(j)
							+ " Value is: " + act.get(i).get(keysList.get(j)));
				} else {
					System.out.println("Records doesn't match");
					System.out.println("Expected Record value: Record Position: " + i + " Key is: " + keysList.get(j)
							+ " Value is: " + exp.get(i).get(keysList.get(j)));
					logger.log(Status.FAIL,
							"Record Position: " + i + "Key is: " + keysList.get(j) + " Expected - Value is: "
									+ exp.get(i).get(keysList.get(j)) + "Actual - Value is: "
									+ act.get(i).get(keysList.get(j)));
					System.out.println("Actual Record value: Record Position: " + i + " Key is: " + keysList.get(j)
							+ " Value is: " + act.get(i).get(keysList.get(j)));
				}
			}
		}
	}

	public LinkedHashMap<Integer, String> fileToStrobj(String fileName) throws Exception {
		LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
		BufferedReader br;
		br = new BufferedReader(new FileReader(new File(fileName)));
		String line;
		int counter = 0;
		while ((line = br.readLine()) != null) {
			System.out.println("Line is: " + line);
			map.put(counter, line.trim());
			counter++;
		}
		br.close();
		return map;
	}

	public List<LinkedHashMap<String, String>> buildImpl(LinkedHashMap<Integer, String> recordMap,
			PropertyUtils utils) {
		keysList.clear();
		LinkedHashMap<String, String> keyValues = buildKeyStructure(recordMap, utils);
		mappedRecords = new ArrayList<LinkedHashMap<String, String>>();
		for (int i = 0; i < recordMap.size(); i++) {
			LinkedHashMap<String, String> finalMapping = new LinkedHashMap<String, String>();
			for (int j = 0; j < keyValues.size(); j++) {
				String value = splitRecord(recordMap.get(i), keyValues.get(keysList.get(j)));
				finalMapping.put(keysList.get(j), value);
			}
			mappedRecords.add(finalMapping);
		}
		return mappedRecords;
	}

	public LinkedHashMap<String, String> buildKeyStructure(LinkedHashMap<Integer, String> map,
			PropertyUtils utilstemp) {
		LinkedHashMap<String, String> keyValueMap = new LinkedHashMap<String, String>();
		Set<Object> keys = utilstemp.getAllKeys();
		for (Object obj : keys) {
			String key = (String) obj;
			System.out.println("Key is: " + key + "Value is: " + utilstemp.getProperty(key));

			keysList.add(key);
			keyValueMap.put(key, utilstemp.getProperty(key));
		}
		return keyValueMap;
	}

	public String splitRecord(String record, String value) {
		int startPosition = Integer.valueOf(value.split(",")[0]);
		int endPosition = Integer.valueOf(value.split(",")[1]);
		return record.substring(startPosition, endPosition + 1);
	}

}
