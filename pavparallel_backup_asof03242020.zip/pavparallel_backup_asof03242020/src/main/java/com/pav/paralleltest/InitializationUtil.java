package com.pav.paralleltest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class InitializationUtil {
	
	String[] getPayTypes(String orgName, String planCode, PropertyUtils props) {
		String paymentTypeConfig = orgName.concat("-").concat(planCode);
		String[] paymentTypes = null;
		String paymentList = props.getProperty(paymentTypeConfig);
		if (paymentList.contains(",")) {
			paymentTypes = paymentList.split(",");
		} else {
			paymentTypes = new String[] { paymentList };
		}
		System.out.println("paymentTypes" + paymentTypes);
		return paymentTypes;

	}

	String[] getPlanCodesForOrg(String orgName, PropertyUtils props) {
		String[] planCodes = null;
		String plansToOrg = props.getProperty(orgName);
		if (plansToOrg.contains(",")) {
			planCodes = plansToOrg.split(",");
		} else {
			planCodes = new String[] { plansToOrg };
		}
		return planCodes;
	}

	HashMap<String, String[]> getKeyValueForFields(String payType) {
		HashMap<String, String[]> keyValueForFields = new HashMap<String, String[]>();
		String[] fieldsToValidateForFCRArray = { "PayeeName", "CheckAmount", "VoucherCode", "StateCode", "FEPSPLIT1HO",
				"FEPSPLIT2SO", "FEPSPLIT3BO", "FEPSPLIT4HMO", "FEPSPLIT5SS", "FEPSPLIT6BF", "PayeeAddress1",
				"PayeeAddress2", "PayeeAddress3", "PayeeCity", "PayeeState", "PayeeZip", "PayeeAlternateID",
				"MBRNumber", "PayeeType", "PaymentType", "TaxId", "PlanCode" };
		String[] fieldsToValidateForSPRElements = { "OutputFormat", "Application", "HPXPrintInd", "MedicalOrDental" };
		String[] fieldsToValidateForNOPRD = { "MailingAddFirstName", "ChkMailingAddLine1", "ChkMailingAddCity",
				"ChkMailingAddState", "ChkMailingAddZip", "CheckAmountSummary" };
		String[] fieldsToValidateForPaymentElements = { "ProviderNumber", "ProviderTaxID", "ProviderNPINumber",
				"PayeeNumber" };
		String[] fieldsToValidateForRemarkElements = { "RemarkCode", "RemarkDescription", "ClaimNumber" };

		String[] fieldsToValidateForClaimElements = { "ClaimNumber" };
		keyValueForFields.put("FCRArray", fieldsToValidateForFCRArray);

		if (!payType.equalsIgnoreCase("SUBCHK")) {
			keyValueForFields.put("SPREElements", fieldsToValidateForSPRElements);
			keyValueForFields.put("NOPRD", fieldsToValidateForNOPRD);
			keyValueForFields.put("PaymentElements", fieldsToValidateForPaymentElements);
			keyValueForFields.put("RemarkElements", fieldsToValidateForRemarkElements);
			keyValueForFields.put("ClaimArrayElements", fieldsToValidateForClaimElements);
		}
		return keyValueForFields;
	}
}
